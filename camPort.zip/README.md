# frontend-nanodegree-mobile-portfolio

This is a project for the Front-End Web Develper Nanodegree.
The finished project is in the dist/ folder.
PLEASE USE GOOGLE CROME TO VIEW
  All images are compressed with webp.

scr Folder
----------
This is the non-optimized code folder.
Gulp is required to compile the code along with the moduals:
  -gulp-jshint
  -gulp-concat
  -gulp-uglify
  -gulp-rename
  -gulp-inline-css
  -gulp-minify-html
  -gulp-webp
  -gulp-inline-source